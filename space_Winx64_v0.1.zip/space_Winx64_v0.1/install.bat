@echo off
color 0A
echo ===================================================
echo   Installing Space Compiler ...
echo ===================================================
echo.

:: 1. Create a permanent safe folder on their C: drive
echo [1/3] Creating directory at C:\SpaceCompiler...
mkdir C:\SpaceCompiler 2>nul

:: 2. Copy all the files from the downloaded folder into the permanent folder
echo [2/3] Copying compiler files...
xcopy /E /I /Y "%~dp0*" "C:\SpaceCompiler\" >nul

:: 3. Automatically add that permanent folder to their Windows PATH
echo [3/3] Setting up Universal Environment Variables...
powershell -Command "$oldPath = [Environment]::GetEnvironmentVariable('Path', 'User'); if ($oldPath -notmatch 'C:\\SpaceCompiler') { [Environment]::SetEnvironmentVariable('Path', \"$oldPath;C:\SpaceCompiler\", 'User') }"

echo.
echo ===================================================
echo INSTALLATION SUCCESSFUL!
echo ===================================================
echo.
echo The compiler is now Universal.
echo You can safely delete this downloaded folder.
echo.
echo Open a brand NEW Command Prompt or PowerShell,
echo go to any folder, and type 'space test.sp' to run!
echo.
pause
